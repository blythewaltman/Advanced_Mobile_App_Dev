//
//  DataViewController.swift
//  final
//
//  Created by Blythe Waltman on 3/17/21.
//

import UIKit

class DataViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Library"
        APICaller.shared.getUsersRecentlyPlayed { [weak self] result in
            switch result {
            case .success(let model):
                self?.updateUI(with: model)
                break
            case .failure(let error):
                print(error.localizedDescription)
                self?.failedToGetProfile()
            }
        }
    }
    
    private func updateUI(with model: UserRecentPlays){
        for item in model.items{
            print(item.track.album.artists[0].name)
        }
    }
    
    private func failedToGetProfile(){
        let label = UILabel(frame: .zero)
        label.text = "Failed to load profile."
        label.sizeToFit()
        label.textColor = .secondaryLabel
        view.addSubview(label)
        label.center = view.center
    }


}
