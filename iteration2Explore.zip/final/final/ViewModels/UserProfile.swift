//
//  Profile.swift
//  Spotify2
//
//  Created by Blythe Waltman on 3/16/21.
//

import Foundation

struct UserProfile: Codable{
    let country : String
    let display_name: String
    let email: String
   // let explicit_content: [String: String]
  //  let external_urls: [String: String]
    let id: String
  //  let product: String
   // let images: [UserImage]
}

struct UserImage: Codable{
    let url: String
}

