//
//  AuthResponse.swift
//  Spotify2
//
//  Created by Blythe Waltman on 3/16/21.
//

import Foundation

struct AuthResponse : Codable{
    let access_token : String
    let expires_in : Int
    let refresh_token : String?
    let scope : String
    let token_type: String
}
