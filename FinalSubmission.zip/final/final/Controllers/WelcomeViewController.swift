//
//  WelcomeViewController.swift
//  Spotify2
//
//  Created by Blythe Waltman on 3/16/21.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    
    @IBOutlet weak var signInButton: UIButton!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Spotify"
        signInButton.layer.cornerRadius = 5
        signInButton.layer.borderWidth = 1
        signInButton.layer.borderColor = UIColor.black.cgColor
        signInButton.contentEdgeInsets = UIEdgeInsets(top: 5, left: 5,bottom: 5,right: 5)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "signIn"{
            let vc = (segue.destination as! UINavigationController).topViewController as! AuthViewController
            vc.completionHandler = { [weak self] success in
                DispatchQueue.main.async{
                    self?.handleSignIn(success: success)
                }
            }
        }
    }
    
    private func handleSignIn(success: Bool){
        guard success else{
            let alert = UIAlertController(title: "Oops", message: "Something went wrong when signing in.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))
            present(alert, animated: true)
            return
        }
    }
}
