//
//  PrimaryViewController.swift
//  final
//
//  Created by Blythe Waltman on 3/17/21.
//

import UIKit
import SDWebImage

class PrimaryViewController: UITableViewController {
    

    @IBOutlet var tableViewOutlet: UITableView!

    var recentArtistNames = [String]()
    var recentArtistImageData = [ArtistImage]()
    var recentArtistIDString = ""
    
    var topArtistNames = [String]()
    var topArtistImageData = [ArtistImage]()
    var topArtistIDString = ""
    
    var showRecentlyListenedArtists:Bool = true
    
    
    @IBOutlet weak var segControl: UISegmentedControl!
    
    @IBAction func switchArtists(_ sender: Any) {
        switch segControl.selectedSegmentIndex
           {
           case 0:
            showRecentlyListenedArtists = true
            title = "Recent"
            self.tableViewOutlet.reloadData()
           case 1:
            showRecentlyListenedArtists = false
            title = "Top"
            self.tableViewOutlet.reloadData()
           default:
               break
           }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
            title = "Recent"
            APICaller.shared.getUsersRecentlyPlayed { [weak self] result in
                switch result {
                case .success(let model):
                    self?.updateUIWithRecentPlays(with: model)
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    self?.failedToGetProfile()
                }
            }
        
        APICaller.shared.getUsersTopArtists{ [weak self] result in
            switch result {
            case .success(let model):
                self?.updateUITopArtists(with: model)
                break
            case .failure(let error):
                print(error.localizedDescription)
                self?.failedToGetProfile()
            }
        }
    }
    
    
    private func updateUITopArtists(with model: UserTopArtist){
        for item in model.items{
            if topArtistNames.contains(item.name) == false{
                topArtistNames.append(item.name)
                topArtistIDString = topArtistIDString + "\(item.id)%2C"
            }
        }
        topArtistIDString.removeLast()
        topArtistIDString.removeLast()
        topArtistIDString.removeLast()
        print("\(topArtistIDString)")
    
        DispatchQueue.main.async {
            self.tableViewOutlet.reloadData()
            APICaller.shared.getArtistInfo(artists: self.topArtistIDString){ [weak self] result in
                switch result {
                case .success(let model):
                    self?.getTopArtistImages(with: model)
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    self?.failedToGetProfile()
                }
            }
        }
    }
    
    
    private func updateUIWithRecentPlays(with model: UserRecentPlays){
        for item in model.items{
            if recentArtistNames.contains(item.track.album.artists[0].name) == false{
                recentArtistNames.append(item.track.album.artists[0].name)
                recentArtistIDString = recentArtistIDString + "\(item.track.album.artists[0].id)%2C"
            }
        }
        recentArtistIDString.removeLast()
        recentArtistIDString.removeLast()
        recentArtistIDString.removeLast()
        print("\(recentArtistIDString)")
        
        DispatchQueue.main.async {
            APICaller.shared.getArtistInfo(artists: self.recentArtistIDString){ [weak self] result in
                switch result {
                case .success(let model):
                    self?.getRecentArtistImages(with: model)
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    self?.failedToGetProfile()
                }
            }
        }
    }
    
    private func getRecentArtistImages(with model: ArtistInfo){
        for artist in model.artists{
            print("Artist: \(artist.name) Image: \(artist.images[0].url)")
            recentArtistImageData.append(ArtistImage(name: artist.name, url: artist.images[0].url))
            DispatchQueue.main.async {
                self.tableViewOutlet.reloadData()
            }
        }
    }
    
    private func getTopArtistImages(with model: ArtistInfo){
        for artist in model.artists{
            print("Artist: \(artist.name) Image: \(artist.images[0].url)")
            topArtistImageData.append(ArtistImage(name: artist.name, url: artist.images[0].url))
            DispatchQueue.main.async {
                self.tableViewOutlet.reloadData()
            }
        }
    }
    
    private func failedToGetProfile(){
        
        let label = UILabel(frame: .zero)
        label.text = "Failed to load profile."
        label.sizeToFit()
        label.textColor = .secondaryLabel
        view.addSubview(label)
        label.center = view.center
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(showRecentlyListenedArtists == true){
            return recentArtistImageData.count
        }
        else{
            return topArtistImageData.count
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        print("Recent artists image count: \(recentArtistImageData.count)")
        print("Index path: \(indexPath.row)")
        print("/")
        
        if(showRecentlyListenedArtists == true){
            if(indexPath.row < recentArtistImageData.count){
                cell.textLabel!.text = recentArtistImageData[indexPath.row].name
                let urlString = recentArtistImageData[indexPath.row].url
                let url = URL(string: urlString)
                let artistImage = UIImageView()
                artistImage.sd_setImage(with: url!, completed: nil)
                cell.imageView!.image = artistImage.image
            }
        }
        else{
            if(indexPath.row < topArtistImageData.count){
                cell.textLabel!.text = topArtistImageData[indexPath.row].name
                let urlString = topArtistImageData[indexPath.row].url
                let url = URL(string: urlString)
                let artistImage = UIImageView()
                artistImage.sd_setImage(with: url!, completed: nil)
                cell.imageView!.image = artistImage.image
            }
        }
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ArtistDetails" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let detailVC = segue.destination as! ArtistDetailsViewController
                if(showRecentlyListenedArtists == true){
                    detailVC.title = recentArtistNames[indexPath.row] + " Songs"
                    detailVC.artistName = recentArtistNames[indexPath.row]
                }
                else{
                    detailVC.title = topArtistNames[indexPath.row] + " Songs"
                    detailVC.artistName = topArtistNames[indexPath.row]
                }
            }
        }
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
