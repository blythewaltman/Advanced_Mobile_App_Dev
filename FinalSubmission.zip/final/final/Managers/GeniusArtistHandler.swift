//
//  GeniusArtistHandler.swift
//  final
//
//  Created by Blythe Waltman on 3/21/21.
//

import Foundation

class GeniusArtistHandler {
    var songs = [SongInfo]()
    var onDataUpdate: ((_ data: [SongInfo]) -> Void)?
    
    func loadjson(_ artist : String){
        
        let headers = [
            "x-rapidapi-key": "ccb661f7f7mshe9e373d8f971d4bp1127cajsnbf33eefb2aa0",
            "x-rapidapi-host": "genius.p.rapidapi.com"
        ]
        
        var addArtist = artist
        var urlPath = "https://genius.p.rapidapi.com/search?q="
        addArtist = addArtist.replacingOccurrences(of: " ", with: "%20")
        urlPath += addArtist
        
        
        guard let url = URL(string: urlPath)
            else {
                print("url error")
                return
            }
        
        var request = URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 10.0)
        request.httpMethod = "GET"
        request.allHTTPHeaderFields = headers
        
        let session = URLSession.shared.dataTask(with: request, completionHandler: {(data, response, error) in
            let httpResponse = response as! HTTPURLResponse
            let statusCode = httpResponse.statusCode
            print(statusCode)
            guard statusCode == 200
                else {
                    print("file download error")
                    return
                }
            //download successful
            print("download complete")
            //parse json asynchronously
            DispatchQueue.main.async {self.parsejson(data!)}
        })
        //must call resume to run session
        session.resume()
    }
    
    func parsejson(_ data: Data){
        do
        {
            let apiData = try JSONDecoder().decode(GeniusArtist.self, from: data)
           // let apiData = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
            print(apiData)
            
            for hit in apiData.response.hits
            {
                songs.append(hit.result)
            }
             
        }
        catch let jsonErr
        {
            print("json error")
            print(jsonErr.localizedDescription)
            return
        }
        print("parsejson done")
        //passing the results to the onDataUpdate closure
        onDataUpdate?(songs)
    }

    func getArtistData() -> [SongInfo] {
        return songs
    }

}
