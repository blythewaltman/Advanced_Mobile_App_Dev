//
//  APICaller.swift
//  Spotify2
//
//  Created by Blythe Waltman on 3/16/21.
//

/*
 
Spotify API calls help was from this tutorial - https://www.youtube.com/watch?v=MfhwNT5uT2s
 
*/

import Foundation

final class APICaller {
    static let shared = APICaller()
    
    private init(){}
    
    struct Constants{
        static let baseAPIURL = "https://api.spotify.com/v1"
    }
    
    enum APIError : Error {
        case faileedToGetData
    }
    
    public func getUsersTopArtists(completion: @escaping (Result<UserTopArtist, Error>) -> Void){
        createRequest(
            with: URL(string: Constants.baseAPIURL + "/me/top/artists?limit=50"),
            type: .GET
        ) { baseRequest in
            let task = URLSession.shared.dataTask(with: baseRequest) { data, _, error in
                guard let data = data, error == nil else{
                    completion(.failure(APIError.faileedToGetData))
                    return
                }
                
                do {
                   // let result = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                    let result = try JSONDecoder().decode(UserTopArtist.self, from: data)
                    print(result)
                    completion(.success(result))
                }
                catch{
                    print(error.localizedDescription)
                    completion(.failure(error))
                }
            }
            task.resume()
        }
    }
    
    public func getUsersRecentlyPlayed(completion: @escaping (Result<UserRecentPlays, Error>) -> Void){
        createRequest(
            with: URL(string: Constants.baseAPIURL + "/me/player/recently-played?limit=50"),
            type: .GET
        ) { baseRequest in
            let task = URLSession.shared.dataTask(with: baseRequest) { data, _, error in
                guard let data = data, error == nil else{
                    completion(.failure(APIError.faileedToGetData))
                    return
                }
                
                do {
                    
                    let result = try JSONDecoder().decode(UserRecentPlays.self, from: data)
                    completion(.success(result))
                }
                catch{
                    print(error.localizedDescription)
                    completion(.failure(error))
                }
            }
            task.resume()
        }
    }
    
    public func getArtistInfo(artists : String, completion: @escaping (Result<ArtistInfo, Error>) -> Void){
        createRequest(
            with: URL(string: Constants.baseAPIURL + "/artists?ids=\(artists)"),
            type: .GET
        ) { baseRequest in
            let task = URLSession.shared.dataTask(with: baseRequest) { data, _, error in
                guard let data = data, error == nil else{
                    completion(.failure(APIError.faileedToGetData))
                    return
                }
                
                do {
                   // print("artist Ids are : \(artists)")
                    let result = try JSONDecoder().decode(ArtistInfo.self, from: data)
                   // let result = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
                    print(result)
                    completion(.success(result))
                }
                catch{
                    print(error.localizedDescription)
                    completion(.failure(error))
                }
            }
            task.resume()
        }
    }
    
    // MARK: - Private
    
    enum HTTPMethod : String {
        case GET
        case POST
    }
    
    private func createRequest(
        with url: URL?,
        type: HTTPMethod,
        completion: @escaping (URLRequest) -> Void){
        AuthManager.shared.withValidToken{ token in
            guard let apiURL = url else {
                return
            }
            var request = URLRequest(url: apiURL)
            request.setValue("Bearer \(token)",
                             forHTTPHeaderField: "Authorization")
            request.httpMethod = type.rawValue
            request.timeoutInterval = 30
            completion(request)
        }
    }
}
