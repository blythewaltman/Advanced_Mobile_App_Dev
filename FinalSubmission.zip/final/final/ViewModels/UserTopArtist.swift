//
//  UserTopArtist.swift
//  final
//
//  Created by Blythe Waltman on 4/21/21.
//

import Foundation

struct UserTopArtist : Codable{
    var items = [Artist]()
}

struct imageUrl : Codable{
    let url : String
}

struct Artist : Codable{
    let name : String
    let id : String
    let images : [imageUrl]
}






