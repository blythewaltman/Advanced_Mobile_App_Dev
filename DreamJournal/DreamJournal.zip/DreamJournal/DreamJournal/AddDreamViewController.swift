//
//  AddDreamViewController.swift
//  DreamJournal
//
//  Created by Blythe Waltman on 3/13/21.
//

import UIKit

class AddDreamViewController: UIViewController {
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var dreamTextField: UITextView!
    
    
    var addedTitle = String()
    var addedDream = String()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "saveSegue"{
            if dreamTextField.text?.isEmpty == false && titleTextField.text?.isEmpty == false {
                addedDream = dreamTextField.text!
                addedTitle = titleTextField.text!
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dreamTextField!.layer.borderWidth = 1
        dreamTextField!.layer.borderColor = UIColor.gray.cgColor
        titleTextField!.layer.borderColor = UIColor.gray.cgColor
        

    }

}
