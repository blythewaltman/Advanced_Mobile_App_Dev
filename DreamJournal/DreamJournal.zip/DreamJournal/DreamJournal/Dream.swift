//
//  Dream.swift
//  DreamJournal
//
//  Created by Blythe Waltman on 3/13/21.
//

import Foundation
import FirebaseFirestoreSwift

struct Dream : Codable, Identifiable{
    @DocumentID var id: String?
    var Dream : String
    var Title : String
}
