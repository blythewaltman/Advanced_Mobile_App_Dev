//
//  DreamDataHandler.swift
//  DreamJournal
//
//  Created by Blythe Waltman on 3/13/21.
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class DreamDataHandler{
    let db = Firestore.firestore()
    var DreamData = [Dream]()
    
    var onDataUpdate: ((_ data: [Dream]) -> Void)?
    
    func dbSetup(){
        db.collection("journalEntries")
            .addSnapshotListener{ querySnapshot, error in
                guard let documents = querySnapshot?.documents else{
                    print("Error fetching snapshot results: \(error!)")
                    return
                }
                self.DreamData = documents.compactMap { document ->Dream? in
                    return try? document.data(as: Dream.self)
                }
                self.onDataUpdate?(self.DreamData)
            }
    }
    
    func addDream(Title:String, Dream:String){
        let dreamCollection = db.collection("journalEntries")
        
        //create Dictionary
        let newDreamDict = ["Title": Title, "Dream": Dream]
        
        // Add a new document with a generated id
        var ref: DocumentReference? = nil
        ref = dreamCollection.addDocument(data: newDreamDict) {err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added with ID: \(ref!.documentID)")
            }
        }
    }
    
    func deleteDream(dreamID: String){
        db.collection("journalEntries").document(dreamID).delete() { err in
            if let err = err {
                print("Error removing document: \(err)")
            } else {
                print("Document successfully removed!")
            }
        }
    }
    
    func getDreams() ->[Dream]{
        return DreamData
    }
    
}

