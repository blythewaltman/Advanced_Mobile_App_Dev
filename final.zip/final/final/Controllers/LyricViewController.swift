//
//  LyricViewController.swift
//  final
//
//  Created by Blythe Waltman on 3/21/21.
//

import UIKit
import WebKit

class LyricViewController: UIViewController {
    
    var webpage : String?
    
    
    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let url = webpage {
            loadWebPage(url)
         }
     }
    
    func loadWebPage(_ urlString: String){
     //the urlString should be a propery formed url
     //creates a URL object
     let myurl = URL(string: urlString)
     //create a URLRequest object
     let request = URLRequest(url: myurl!)
     //load the URLRequest object in our web view
     webView.load(request)
     }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
