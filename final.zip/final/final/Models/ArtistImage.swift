//
//  ArtistImage.swift
//  final
//
//  Created by Blythe Waltman on 3/17/21.
//

import Foundation

struct ArtistImage{
    var name : String
    var url : String
}
