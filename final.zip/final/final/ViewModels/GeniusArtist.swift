//
//  GeniusArtist.swift
//  final
//
//  Created by Blythe Waltman on 3/21/21.
//

import Foundation

struct GeniusArtist : Codable{
    let response : hits
}

struct hits : Codable{
    let hits : [HitInfo]
}

struct HitInfo : Codable{
    let result : SongInfo
}

struct SongInfo : Codable{
    let title : String
    let url : String
}
