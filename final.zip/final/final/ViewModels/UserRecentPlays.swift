//
//  UserRecentPlays.swift
//  Spotify2
//
//  Created by Blythe Waltman on 3/17/21.
//

import Foundation

struct UserRecentPlays : Codable{
    let items : [track]
}

struct track : Codable{
    let track : album
}

struct album : Codable{
    let album : artists
}

struct artists : Codable{
    let artists : [AlbumData]
}

struct AlbumData : Codable{
    let name : String
    let id : String
}

