//
//  ArtistInfo.swift
//  final
//
//  Created by Blythe Waltman on 3/17/21.
//

import Foundation

struct ArtistInfo : Codable{
    let artists : [ArtistData]
}

struct ArtistData : Codable{
    let name : String
    let images : [imageData]
}

struct imageData: Codable{
    let url : String
}
